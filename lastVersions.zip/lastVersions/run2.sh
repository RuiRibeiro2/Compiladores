lex gocompiler2.l
cc lex.yy.c -o gocompiler2
./gocompiler2 <input.txt